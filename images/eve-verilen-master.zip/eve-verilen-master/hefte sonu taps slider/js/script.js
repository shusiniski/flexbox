var index = 0;
 
 function showImage() {
 	var x = document.getElementByClassName("slides");
    alert(x.length);
 	}